clc;
load('RQGPR_Tg.mat');
load('RQGPR_Tx.mat');
load('RQGPR_Tl.mat');
load('RQGPR_E.mat');
load('RQGPR_H.mat');
xx=xlsread('D:\GAN\O_GAN_Cu_generator2_2500.xlsx','Sheet1','U2:AO3000');


xx_E=xx;
xx_H=xx;
xx_Tg=xx;
xx_Tx=xx;
xx_Tl=xx;


%E reduction
load('E_reduction.mat');
for i=1:find(RMSE_mean_min==min(min(RMSE_mean_min)))
    xx_E(:,i_min(i))=[];
end

% H reduction
load('H_reduction.mat');
for i=1:find(RMSE_mean_min==min(min(RMSE_mean_min)))
    xx_H(:,i_min(i))=[];
end


%Tg reduction
load('Tg_reduction.mat');
for i=1:find(RMSE_mean_min==min(min(RMSE_mean_min)))
    xx_Tg(:,i_min(i))=[];
end

%Tx reduction
load('Tx_reduction.mat');
for i=1:find(RMSE_mean_min==min(min(RMSE_mean_min)))
    xx_Tx(:,i_min(i))=[];
end


%Tl reduction 
load('Tl_reduction.mat');
for i=1:find(RMSE_mean_min==min(min(RMSE_mean_min)))
    xx_Tl(:,i_min(i))=[];
end

Tg=RQGPR_Tg.predictFcn(xx_Tg);
Tx=RQGPR_Tx.predictFcn(xx_Tx);
Tl=RQGPR_Tl.predictFcn(xx_Tl);
E=RQGPR_E.predictFcn(xx_E);
H=RQGPR_H.predictFcn(xx_H);

property=[E,H,Tg,Tx,Tl];