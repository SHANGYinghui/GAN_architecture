%This file read the generated 100 .mat files and write the compositions
clc;
clear;
load('ZrBMG_D1.mat');%read the dataset file

%one can change the element information
Element={'Zr','Cu','Al','Ni','Ag','Ti','Nb','Co'};%Zr compositions
% Element={'Fe','B','C','Si','Mo','P','Y','Co','Cr','Nb'};%Fe 
% Element={'La','Al','Cu','Ni','Ag','Co','Ce','Mg'};%La compositions properties
% Element={'Ti','Cu','Ni','Zr','Be','Sn','Si','B'};%Ti compositions
% Element={'Zr','Cu','Al','Ni','Ag','Ti','Nb','Fe'};%Zr properties
% Element={'Zr','Ti','Cu','Ni','Al','Nb','Ag','Hf'};%Hybrid

ele_no=length(Element);
fea_no=length(Vect(:,1))-ele_no;
for I=1:100
    filename=sprintf('fake%d',I);
    load(filename);
    Size=size(images_fake);
    

    Comp=zeros(Size(1),Size(2));

    for i=1:Size(1)

        for j=1:Size(2)

            Comp(i,j)=images_fake(i,1,1,j);
        end
    end
    feature_norm=Comp;
    id=[ele_no+1:Size(1)];
    Comp(id,:)=[];
    Fraction_all=zeros(ele_no,Size(2));
    Ind=zeros(ele_no,Size(2));



    Element=Element';
    CHAR=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T'];
    for i=1:Size(2)
        [Fraction_all(:,i),Ind(:,i)]=sort(Comp(:,i),'descend');
        Composition_all(:,i)=Element(Ind(:,i));
        Fraction_all(:,i)=Fraction_all(:,i)/sum(Fraction_all(:,i));

        for k=1:ele_no
            if Fraction_all(k,i)<0.001
                Fraction_all(k,i)=0;
                Composition_all(k,i)={'0'};
            else
                Fraction_all(k,i)=100*roundn(Fraction_all(k,i),-3);
            end
        end
    end

    for i=1:Size(2)
        Fraction=num2cell(Fraction_all(Fraction_all(:,i)~=0,i));
        Composition=Composition_all(1:size(Fraction),i);
        MG=reshape(cat(2,Composition,Fraction)',[],1);
        MG=MG'; 
        if length(MG)<17
            xlswrite('New_Zr',MG,sprintf('A%d:%s%d',I,CHAR(length(MG)),I));
        end
    end

    if fea_no~=0
        id=[1:ele_no];
        feature_norm(id)=[];
        feature_norm=feature_norm';


        for i=1:fea_no
            feature(I,i)=feature_norm(i)*max(abs(Vect(ele_no+i,:)));
        end
    end

    loss(I)=gen_loss(100);
end

%Record the generator loss
loss=loss';





