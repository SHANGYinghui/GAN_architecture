clc;

clear;

%*************************************************************************
%the code aims to input the features and the labels of the neutral network
%and starts the training of artificial neural network
%*************************************************************************


%Input  the parameters, including features and labels
features = xlsread('D:\Dataset\Dataset_Tl.xlsx','Sheet1','E2:Y1000');
labels = xlsread('D:\Dataset\Dataset_Tl.xlsx','Sheet1','AC2:AC1000');
%features = xlsread('E_comb.xlsx','E2:Y3270');
%labels = xlsread('E_comb.xlsx','AB2:AB3270');

All=cat(2,features,labels);

N=length(features(1,:));

for k=1:N-1
        
    n=N-k+1;
    
    for i=1:n

        subset=All;%
        subset(:,i)=[];
        
        for j=1:30
            
            currentfunction = sprintf('RQGPRtraining_%d',N-k);
            [RQGPR,RMSE(k,i,j)]=feval(currentfunction,subset);%training RQGPR models

            %RMSE(k,i,j)=rand; %for testing code

        end
        
    end
    
    
    for i=1:n
        
        RMSE_mean(k,i)=mean(RMSE(k,i,:));
        
    end
    RMSE_mean_k=RMSE_mean(k,:);
    [RMSE_mean_min(k),i_min(k)]=min(RMSE_mean_k(find(RMSE_mean_k~=0))); % record the minimum RMSE in reduction loop k % identify the position of minimum RMSE
    
    All(:,i_min(k))=[];
    
end
RMSE_mean_min=RMSE_mean_min';
i_min=i_min';
save('Tl_reduced');